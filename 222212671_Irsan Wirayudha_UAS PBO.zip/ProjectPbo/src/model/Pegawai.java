/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author User
 */
public class Pegawai {
    private int id;
    private String first_name;
    private String Email; 
    private String surname;     
    private Integer Dob; 
    private String Telephone;
    private String Address;
    private String Department;
    private String Gender;
    private String Salary;
    private String Address2;
    private String Apartment;
    private String Post_code;  
    private String Designation;
    private String Status;
    private String Date_hired;
    private String job_title;
    
    public Pegawai (Integer id, String first_name, String Email , String surname, Integer Dob, String Telephone, String Address, String Department, String Gender, String Salary, String Address2, String  Apartment, String Post_code,String Designation, String Status, String Date_hired, String job_title ) {
        this.id = id;
        this.first_name = first_name;
        this.Email = Email;
        this.surname = surname;
        this.Dob= Dob;
        this.Telephone = Telephone;
        this.Address = Address;
        this.Department = Department;
        this.Gender = Gender;
        this.Salary = Salary;
        this.Address2 = Address2;
        this.Apartment = Apartment;
        this.Post_code = Post_code;
        this.Designation = Designation;
        this.Status = Status;
        this.Date_hired = Date_hired;
        this.job_title = job_title;
        
        
    }
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getFirst_name() {
        return first_name;
    }
    
    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }
    
    public String getEmail() {
        return Email;
    }
    
    public void setEmail(String Email) {
        this.Email = Email;
    }
    
    public String getSurname() {
        return surname;
    }
    
    public void setSurname(String surname) {
        this.surname = surname;
    }
    
    public Integer getDob() {
        return Dob;
    }
    
    public void setDob(Integer Dob) {
        this.Dob = Dob;
    }
    
    public String getTelephone() {
        return Telephone;
    }
    
    public void setTelephone(String Telephone) {
        this.Telephone = Telephone;
    }
    
    public String getAddress() {
        return Address;
    }
    
    public void setAddress(String Address) {
        this.Address = Address;
    }
    
    public String getDepartment() {
        return Department;
    }
    
    public void setDepartment(String Department) {
        this.Department = Department;
    }
    
    public String getGender() {
        return Gender;
    }
    
    public void setGender(String Gender) {
        this.Gender = Gender;
    }
    
    public String getSalary() {
        return Salary;
    }
    
    public void setSalary(String Salary) {
        this.Salary =Salary;
    }
    
    public String getAddress2() {
        return Address2;
    }
    
    public void setAddress2(String Address2) {
        this.Address2 =Address2;
    }
    
    public String getApartment() {
        return Apartment;
    }
    
    public void setApartment(String Apartment) {
        this.Apartment =Apartment;
    }
    
    public String getPost_code() {
        return Post_code;
    }
    
    public void setPost_code(String Post_code) {
        this.Post_code = Post_code;
    }
    
    public String getDesignation() {
        return Designation;
    }
    
    public void Designation(String Designation) {
        this.Designation = Designation;
    }
    
    public String getStatus() {
        return Status;
    }
    
    public void Status(String Status) {
        this.Status = Status;
    }
    
    public String getDate_hired() {
        return Date_hired;
    }
    
    public void Date_hired(String Date_hired) {
        this.Date_hired = Date_hired;
    }
    
    public String getjob_title() {
        return job_title;
    }
    
    public void job_title(String job_title) {
        this.job_title = job_title;
    }
}
