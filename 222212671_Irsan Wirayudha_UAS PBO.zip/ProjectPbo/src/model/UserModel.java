/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author User
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import projectpbo.Emp;

public class UserModel {
    private Connection conn;

    public UserModel(Connection conn) {
        this.conn = conn;
    }

    public boolean authenticateUser(String username, String password, String division) throws SQLException {
        String sql = "SELECT id, username, password, division FROM Users WHERE username = ? AND password = ? AND division = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, username);
            pst.setString(2, password);
            pst.setString(3, division);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    int id = rs.getInt("id");
                    Emp.empId = id;
                    Emp.empname = rs.getString("username");
                    return true;
                } else {
                    return false;
                }
            }
        }
    }

    public void logUserAction(int userId, String action) throws SQLException {
        String sql = "INSERT INTO Audit (emp_id, date, status) VALUES (?, ?, ?)";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            Date currentDate = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            String timeString = sdf.format(currentDate);
            DateFormat df = DateFormat.getDateInstance();
            String dateString = df.format(currentDate);

            pst.setInt(1, userId);
            pst.setString(2, timeString + " / " + dateString);
            pst.setString(3, action);
            pst.executeUpdate();
        }
    }
}